Coloca aquí los pantallazos del CRUD de cursos, la asignación y el diagrama de BD.
