<nav class="blue darken-2">
  <div class="nav-wrapper container">
    <a href="<?= base_url('/') ?>" class="brand-logo">Gestión</a>
    <ul id="nav-mobile" class="right hide-on-med-and-down">
      <li><a href="<?= base_url('alumnos') ?>">Alumnos</a></li>
      <li><a href="<?= base_url('cursos') ?>">Cursos</a></li>
    </ul>
  </div>
</nav>
