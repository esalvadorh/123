<?= $this->include('partials/navbar') ?>
<div class="container">
  <h4>Alumnos</h4>
  <?php if(session('msg')): ?><p class="green-text"><?= esc(session('msg')) ?></p><?php endif; ?>
  <table class="striped responsive-table">
    <thead>
      <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Correo</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($alumnos as $al): ?>
      <?php
        $color = $al['tiene_cursos'] ? 'blue-text text-darken-2' : 'grey-text';
        $visibilityClass = $al['tiene_cursos'] ? '' : 'hide';
      ?>
      <tr data-alumno-id="<?= esc($al['id']) ?>">
        <td><?= esc($al['id']) ?></td>
        <td><?= esc($al['nombre']) ?></td>
        <td><?= esc($al['correo'] ?? '') ?></td>
        <td>
          <a href="#modal-asignar"
             class="btn-flat modal-trigger asignar-trigger <?= $color ?>"
             title="Asignar cursos"
             data-id="<?= esc($al['id']) ?>"
             data-nombre="<?= esc($al['nombre']) ?>">
             <i class="material-icons">playlist_add</i>
          </a>
          <a href="#modal-ver"
             class="btn-flat modal-trigger ver-trigger <?= $visibilityClass ?>"
             title="Ver cursos"
             data-id="<?= esc($al['id']) ?>"
             data-nombre="<?= esc($al['nombre']) ?>">
             <i class="material-icons green-text">visibility</i>
          </a>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<div id="modal-asignar" class="modal">
  <div class="modal-content">
    <h5>Asignar cursos a <span id="alumnoNombre"></span></h5>
    <form id="form-asignar">
      <div id="lista-cursos" class="row" style="max-height: 300px; overflow:auto;"></div>
      <input type="hidden" id="alumnoIdAsignar" name="alumno_id">
    </form>
  </div>
  <div class="modal-footer">
    <a href="#!" id="btn-guardar-asignacion" class="modal-close waves-effect waves-green btn">Guardar</a>
  </div>
</div>

<div id="modal-ver" class="modal">
  <div class="modal-content">
    <h5>Cursos asignados a <span id="alumnoNombreVer"></span></h5>
    <ul id="lista-cursos-asignados" class="collection"></ul>
  </div>
  <div class="modal-footer">
    <a href="#!" class="modal-close waves-effect waves-green btn">Cerrar</a>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  var modals = document.querySelectorAll('.modal');
  if (M && M.Modal) { M.Modal.init(modals, {}); }

  document.querySelectorAll('.asignar-trigger').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.id;
      const nombre = btn.dataset.nombre;
      document.getElementById('alumnoNombre').textContent = nombre;
      document.getElementById('alumnoIdAsignar').value = id;

      const res = await fetch('<?= base_url('alumnos/asignar/') ?>' + id);
      const data = await res.json();

      const cont = document.getElementById('lista-cursos');
      cont.innerHTML = '';
      (data.cursos || []).forEach(c => {
        const checked = (data.asignados || []).includes(String(c.id)) || (data.asignados || []).includes(Number(c.id));
        cont.insertAdjacentHTML('beforeend', `
          <div class="col s12 m6">
            <label>
              <input type="checkbox" class="filled-in curso-check" value="${c.id}" ${checked?'checked':''}/>
              <span>${c.nombre}</span>
            </label>
          </div>
        `);
      });
    });
  });

  document.getElementById('btn-guardar-asignacion').addEventListener('click', async (e) => {
    e.preventDefault();
    const alumnoId = document.getElementById('alumnoIdAsignar').value;
    const seleccionados = [...document.querySelectorAll('.curso-check:checked')].map(x=>x.value);

    const form = new FormData();
    seleccionados.forEach(v => form.append('curso_ids[]', v));

    const res = await fetch('<?= base_url('alumnos/guardar-asignacion/') ?>' + alumnoId, {
      method: 'POST',
      body: form
    });
    const data = await res.json();

    const row = document.querySelector(`tr[data-alumno-id="${alumnoId}"]`);
    if(row){
      const asignarIcon = row.querySelector('.asignar-trigger');
      const verIcon = row.querySelector('.ver-trigger');
      if(seleccionados.length > 0){
        asignarIcon.classList.remove('grey-text');
        asignarIcon.classList.add('blue-text','text-darken-2');
        verIcon && verIcon.classList.remove('hide');
      } else {
        asignarIcon.classList.remove('blue-text','text-darken-2');
        asignarIcon.classList.add('grey-text');
        verIcon && verIcon.classList.add('hide');
      }
    }
    if (M && M.toast) { M.toast({html: data.ok ? 'Asignación guardada' : 'Error al guardar'}); }
  });

  document.querySelectorAll('.ver-trigger').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.id;
      const nombre = btn.dataset.nombre;
      document.getElementById('alumnoNombreVer').textContent = nombre;

      const res = await fetch('<?= base_url('alumnos/ver-cursos/') ?>' + id);
      const data = await res.json();
      const ul = document.getElementById('lista-cursos-asignados');
      ul.innerHTML = '';

      if((data.cursos || []).length === 0){
        ul.innerHTML = '<li class="collection-item">Sin cursos asignados</li>';
      }else{
        data.cursos.forEach(c => {
          ul.insertAdjacentHTML('beforeend', `<li class="collection-item">${c.nombre}</li>`);
        });
      }
    });
  });
});
</script>
